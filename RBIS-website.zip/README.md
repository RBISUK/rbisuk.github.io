# RBIS — Static Website

A production-ready, research-led marketing site for **Ryan Roberts Behavioural & Intelligence Services (RBIS)**.

## Quick Start (GitHub Pages)
1. Create a new public repo named `rbis-site` (or your choice).
2. Upload all files in this folder (keep the same structure).
3. In **Settings → Pages**, set:
   - **Branch**: `main`
   - **Folder**: `/ (root)`
4. Save. Your site will be live at `https://<your-username>.github.io/<repo>/`.
5. To use a custom domain, add your DNS CNAME pointing to `<your-username>.github.io` and (optionally) add a `CNAME` file with your domain.

## Quick Start (GitLab Pages)
1. Create a new GitLab project and upload these files.
2. Add a `.gitlab-ci.yml` with:
   ```yaml
   pages:
     stage: deploy
     script:
       - mkdir .public
       - cp -r * .public
     artifacts:
       paths:
         - .public
     only:
       - main
   ```
3. In **Settings → Pages**, note your Pages URL. Configure your domain's CNAME to that URL for custom domains.

## Editing
- Content lives in `index.html` (semantic sections).
- Styles in `css/styles.css` (no frameworks, no build step).
- Interactions in `js/main.js` (mobile nav, contact form via mailto).
- Replace `assets/logo.jpg` with your final logo if needed (same filename).

## Privacy / Compliance
- The contact form opens the user's email client to send to **Contact@RBISIntelligence.com**.
- To use a form backend, connect Formspree, Basin, or your chosen service and update the form `action` and `method` accordingly.

## Accessibility & Performance
- Semantic HTML, high color contrast, focus outlines, reduced motion (no heavy animations).
- No client-side frameworks; minimal JS.
