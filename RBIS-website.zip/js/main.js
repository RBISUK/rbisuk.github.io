// RBIS — main.js
(function(){
  const navToggle = document.querySelector('.nav-toggle');
  const navList = document.getElementById('nav-list');
  if(navToggle && navList){
    navToggle.addEventListener('click', () => {
      const open = navList.classList.toggle('show');
      navToggle.setAttribute('aria-expanded', open ? 'true':'false');
    });
    navList.addEventListener('click', (e)=>{
      if(e.target.tagName === 'A'){ navList.classList.remove('show'); navToggle.setAttribute('aria-expanded','false'); }
    });
  }
  // Year
  const y = document.getElementById('year'); if (y) y.textContent = new Date().getFullYear();

  // Mail-to form handler (no external backend required)
  const form = document.getElementById('contact-form');
  if(form){
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const data = new FormData(form);
      const name = encodeURIComponent(data.get('name'));
      const email = encodeURIComponent(data.get('email'));
      const org = encodeURIComponent(data.get('org') || '');
      const message = encodeURIComponent(data.get('message'));
      const subject = encodeURIComponent('RBIS confidential enquiry');
      const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nOrganisation: ${org}\n\nMessage:\n${message}`);
      window.location.href = `mailto:Contact@RBISIntelligence.com?subject=${subject}&body=${body}`;
    });
  }

  // Smooth focus outline on hash navigation for accessibility
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', (e)=>{
      const id = a.getAttribute('href').slice(1);
      const el = document.getElementById(id);
      if(el){
        el.setAttribute('tabindex','-1');
        setTimeout(()=>{ el.focus({preventScroll:true}); el.removeAttribute('tabindex'); }, 300);
      }
    });
  });
})();